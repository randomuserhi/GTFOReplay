const includes = [require("@asl/vanilla/includes.js")];
await Promise.all(includes);