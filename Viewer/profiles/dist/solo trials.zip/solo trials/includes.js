const includes = [require("../vanilla/includes.js")];
await Promise.all(includes);